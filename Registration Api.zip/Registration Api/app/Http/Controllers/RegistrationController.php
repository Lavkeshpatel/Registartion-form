<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Concerns\FilterEmailValidation;

class RegistrationController extends Controller
{
    public function index(){
        return view('form');
    }
    public function register(Request $request){

        $request->validate(
            [
                'firstname' => 'required',
                'email' => 'required|email',
                'password' => 'required|confirmed',
                'password_confiramation' => 'required',
                'lastname'=>'required',
                'phonenumber'=>'required',


            ]
            );
            echo "<pre>";

        print_r($request->all());

    }
}
