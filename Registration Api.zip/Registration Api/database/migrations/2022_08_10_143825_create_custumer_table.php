<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('custumer', function (Blueprint $table) {
            $table->id('custumer_id');
            $table->string('firstname',60);
            $table->string('lastname',60);
            $table->string('email',60);
            $table->int('phonenumber');
            $table->string('password');
            $table->string('password_confiramation');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('custumer');
    }
};
